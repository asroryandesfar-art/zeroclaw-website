#!/usr/bin/python3
"""ZeroClaw Solana Pay - interactive terminal app for Ubuntu.

The public installer ships only this app. On activation the buyer's token
fetches the private package and their signed license from the ZeroClaw
registry; the license is verified by the packaged CLI and the pinned issuer
before it is stored. Every payment action runs that CLI (`solpay`). Tokens are
held in memory only and never written, logged or put in a URL.
"""
import base64
import curses
import datetime
import hashlib
import io
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import tarfile
import tempfile
import urllib.error
import urllib.request
import zlib

APP_VERSION = "0.1.0"
PACKAGE = "@asrori24/zeroclaw-solana-pay"
REGISTRY = os.environ.get("ZSP_REGISTRY_URL", "https://zeroclaw-registry.asroryandesfar.workers.dev/")
ISSUER_SHA256 = "b70f3f78d46f0e078eeb43479e2636e6d50589261aa4b2b6b44dddb463d7bde8"
# Official Sales contact (the owner-approved public WhatsApp link on the website).
SALES_URL = "https://wa.me/6285658321443?text=Hi%2C%20I%27d%20like%20to%20buy%20a%20ZeroClaw%20Solana%20Pay%20license."
DEFAULT_DEVNET_RPC = "https://api.devnet.solana.com"
NETWORK_NAMES = {"devnet": "Devnet", "mainnet-beta": "Mainnet"}
TOKEN_RE = re.compile(r"^[A-Za-z0-9_-]{16,128}$")
ORDER_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
AMOUNT_RE = re.compile(r"^(?:0|[1-9][0-9]{0,11})(?:\.[0-9]{1,9})?$")
B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"

# ZeroClaw mark (from the website logo): navy tile, cyan-to-violet "Z", cyan dot.
# Each character is one pixel; two pixel rows share one terminal row (half blocks).
LOGO = [
    ".BBBBBBBBBB.",
    "BBccccccccdB",
    "BBBBBBBcmBBB",
    "BBBBBBmmBBBB",
    "BBBBmmBBBBBB",
    "BBBmvBBBBBBB",
    "BBvvvvvvvvBB",
    ".BBBBBBBBBB.",
]
LOGO_256 = {"B": 17, "c": 80, "m": 111, "v": 141, "d": 159}
LOGO_8 = {"B": curses.COLOR_BLUE, "c": curses.COLOR_CYAN, "m": curses.COLOR_CYAN, "v": curses.COLOR_MAGENTA, "d": curses.COLOR_WHITE}
LOGO_WIDTH = len(LOGO[0])


# ---------------------------------------------------------------- paths

def _xdg(var, fallback):
    value = os.environ.get(var)
    return value if value and os.path.isabs(value) else os.path.join(os.path.expanduser("~"), fallback)


CONFIG_DIR = os.path.join(_xdg("XDG_CONFIG_HOME", ".config"), "zeroclaw-solana-pay")
DATA_DIR = os.path.join(_xdg("XDG_DATA_HOME", ".local/share"), "zeroclaw-solana-pay")
RUNTIME_DIR = os.path.join(DATA_DIR, "runtime")
SETTINGS_FILE = os.path.join(CONFIG_DIR, "settings.json")
ORDERS_FILE = os.path.join(DATA_DIR, "orders.json")


def license_path():
    custom = os.environ.get("ZSP_LICENSE_FILE")
    return custom if custom and os.path.isabs(custom) else os.path.join(CONFIG_DIR, "license.key")


def private_dir(path):
    os.makedirs(path, mode=0o700, exist_ok=True)
    os.chmod(path, 0o700)
    return path


def write_private(path, text):
    private_dir(os.path.dirname(path))
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), prefix=".tmp-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def read_json(path, default):
    try:
        with open(path, encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return default


def pictures_dir():
    try:
        out = subprocess.run(["xdg-user-dir", "PICTURES"], capture_output=True, text=True, timeout=5).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        out = ""
    base = out if out and os.path.isabs(out) and out != os.path.expanduser("~") else os.path.expanduser("~/Pictures")
    return os.path.join(base, "ZeroClaw")


# ---------------------------------------------------------------- engine (existing CLI)

def engine_path():
    current = os.path.join(RUNTIME_DIR, "current")
    try:
        with open(current, encoding="utf-8") as handle:
            version = handle.read().strip()
        candidate = os.path.join(RUNTIME_DIR, version, "dist", "solpay")
        if re.match(r"^[0-9A-Za-z.+-]+$", version) and os.access(candidate, os.X_OK):
            return candidate
    except OSError:
        pass
    npm = os.path.expanduser("~/zeroclaw-solana-pay-app/node_modules/@asrori24/zeroclaw-solana-pay/dist/solpay")
    return npm if os.access(npm, os.X_OK) else None


def base_env():
    env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "HOME": os.path.expanduser("~"), "LANG": "C.UTF-8"}
    for key in ("XDG_CONFIG_HOME", "ZSP_LICENSE_FILE"):
        if os.environ.get(key):
            env[key] = os.environ[key]
    return env


def run_engine(binary, args, extra=None, timeout=120):
    """Run the CLI; returns (exit_code, json_or_None, message)."""
    env = base_env()
    env.update(extra or {})
    try:
        result = subprocess.run([binary, *args], capture_output=True, text=True, env=env, timeout=timeout)
    except subprocess.TimeoutExpired:
        return 4, None, "The check took too long."
    except OSError as error:
        return 5, None, f"Could not start the ZeroClaw engine ({error.strerror})."
    data, message = None, ""
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else None
    except ValueError:
        data = None
    if result.returncode != 0:
        try:
            message = json.loads(result.stderr.strip().splitlines()[-1]).get("message", "")
        except (ValueError, IndexError, AttributeError):
            message = result.stderr.strip()[-300:]
    return result.returncode, data, message


def network_env(settings, network, wallet):
    if network == "mainnet-beta":
        env = {"SOLANA_CLUSTER": "mainnet-beta", "ALLOW_MAINNET": "true", "PAYMENT_COMMITMENT": "finalized",
               "MAINNET_RPC_PRIMARY": settings.get("mainnet_rpc_primary", ""),
               "INVOICE_DB": os.path.join(private_dir(DATA_DIR), "invoices-mainnet.sqlite")}
        if settings.get("mainnet_rpc_fallback"):
            env["MAINNET_RPC_FALLBACK"] = settings["mainnet_rpc_fallback"]
    else:
        env = {"SOLANA_CLUSTER": "devnet", "ALLOW_MAINNET": "false", "PAYMENT_COMMITMENT": "confirmed",
               "SOLANA_RPC_PRIMARY": settings.get("devnet_rpc") or DEFAULT_DEVNET_RPC,
               "INVOICE_DB": os.path.join(private_dir(DATA_DIR), "invoices-devnet.sqlite")}
    env["MERCHANT_WALLET"] = wallet
    env["STORE_LABEL"] = settings.get("store_label") or "ZeroClaw Store"
    return env


def license_status(binary):
    if not binary or not os.path.exists(license_path()):
        return None
    code, data, _ = run_engine(binary, ["license-check"], timeout=30)
    return data if code == 0 and data and data.get("valid") else None


# ---------------------------------------------------------------- activation

class ActivationError(Exception):
    pass


ACTIVATION_MESSAGES = {
    "format": "That does not look like a ZeroClaw token. Paste the full token from your purchase message.",
    "invalid": "This token is not valid. Check that you pasted the whole token from your purchase message.",
    "revoked": "This token has been revoked. Contact Sales if you think this is a mistake.",
    "network": "Could not connect to the ZeroClaw registry. Check your internet connection and try again.",
    "server": "The ZeroClaw registry had a problem. Wait a minute and try again.",
    "package": "The downloaded package failed its security check. Nothing was installed. Try again or contact Sales.",
    "license": "Your license could not be verified. Nothing was saved. Contact Sales.",
}


def _fetch(url, token, timeout=90):
    request = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}", "Accept": "application/json",
                                                   "User-Agent": f"zeroclaw-desktop/{APP_VERSION}"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.read()
    except urllib.error.HTTPError as error:
        raise ActivationError({401: "invalid", 403: "revoked"}.get(error.code, "server")) from None
    except (urllib.error.URLError, OSError, TimeoutError):
        raise ActivationError("network") from None


def _safe_extract(data, target):
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
        for member in archive.getmembers():
            name = member.name
            if name.startswith("/") or ".." in name.split("/") or not (member.isfile() or member.isdir()):
                raise ActivationError("package")
        if hasattr(tarfile, "data_filter"):
            archive.extractall(target, filter="data")
        else:
            archive.extractall(target)


def activate(token, progress=lambda text: None):
    token = token.strip()
    if not TOKEN_RE.match(token):
        raise ActivationError("format")
    progress("Checking your token...")
    origin = REGISTRY if REGISTRY.endswith("/") else REGISTRY + "/"
    try:
        meta = json.loads(_fetch(origin + PACKAGE.replace("/", "%2f"), token))
        version = meta["dist-tags"]["latest"]
        release = meta["versions"][version]
        license_key = release["zeroclawLicense"]
        tarball, integrity = release["dist"]["tarball"], release["dist"]["integrity"]
    except (ValueError, KeyError, TypeError):
        raise ActivationError("server") from None
    if not tarball.startswith(origin) or not re.match(r"^[0-9A-Za-z.+-]+$", version):
        raise ActivationError("package")  # never send the token to another host
    progress(f"Downloading ZeroClaw {version}...")
    data = _fetch(tarball, token, timeout=180)
    expected = integrity.split("sha512-", 1)[-1]
    if base64.b64encode(hashlib.sha512(data).digest()).decode() != expected:
        raise ActivationError("package")
    progress("Verifying the package and your license...")
    private_dir(RUNTIME_DIR)
    staging = tempfile.mkdtemp(prefix=".install-", dir=RUNTIME_DIR)
    try:
        _safe_extract(data, staging)
        binary = os.path.join(staging, "package", "dist", "solpay")
        if not os.path.isfile(binary):
            raise ActivationError("package")
        os.chmod(binary, 0o755)
        code, issuer, _ = run_engine(binary, ["license-issuer"], timeout=30)
        if code != 0 or not issuer or issuer.get("issuerFingerprint") != ISSUER_SHA256:
            raise ActivationError("package")
        candidate = os.path.join(staging, "license.key")
        write_private(candidate, license_key + "\n")
        code, checked, _ = run_engine(binary, ["license-check", "--license-file", candidate], timeout=30)
        if code != 0 or not checked or not checked.get("valid"):
            raise ActivationError("license")
        final = os.path.join(RUNTIME_DIR, version)
        if os.path.exists(final):
            shutil.rmtree(final)
        os.replace(os.path.join(staging, "package"), final)
        write_private(os.path.join(RUNTIME_DIR, "current"), version + "\n")
        write_private(license_path(), license_key + "\n")
        return checked
    finally:
        shutil.rmtree(staging, ignore_errors=True)


# ---------------------------------------------------------------- helpers

def valid_wallet(address):
    if not 32 <= len(address) <= 44 or any(c not in B58 for c in address):
        return False
    number = 0
    for char in address:
        number = number * 58 + B58.index(char)
    raw = number.to_bytes((number.bit_length() + 7) // 8, "big") if number else b""
    raw = b"\0" * (len(address) - len(address.lstrip("1"))) + raw
    return len(raw) == 32


def copy_text(text):
    tools = []
    if os.environ.get("WAYLAND_DISPLAY"):
        tools.append(["wl-copy"])
    if os.environ.get("DISPLAY"):
        tools += [["xclip", "-selection", "clipboard"], ["xsel", "--clipboard", "--input"]]
    for tool in tools:
        if shutil.which(tool[0]):
            try:
                subprocess.run(tool, input=text.encode(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5, check=True)
                return True
            except (OSError, subprocess.SubprocessError):
                continue
    return False


def open_external(target):
    try:
        subprocess.Popen(["xdg-open", target], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        return True
    except OSError:
        return False


def png_modules(path):
    """Grayscale 8-bit PNG (1 pixel per module) -> rows of booleans (True = light)."""
    with open(path, "rb") as handle:
        data = handle.read()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        return None
    pos, idat, width, height = 8, b"", 0, 0
    while pos < len(data):
        length, kind = struct.unpack(">I4s", data[pos:pos + 8])
        chunk = data[pos + 8:pos + 8 + length]
        pos += 12 + length
        if kind == b"IHDR":
            width, height, depth, color = struct.unpack(">IIBB", chunk[:10])
            if depth != 8 or color != 0:
                return None
        elif kind == b"IDAT":
            idat += chunk
        elif kind == b"IEND":
            break
    raw, rows, prev = zlib.decompress(idat), [], bytearray(width)
    for y in range(height):
        start = y * (width + 1)
        kind, line = raw[start], bytearray(raw[start + 1:start + 1 + width])
        for x in range(width):
            a, b, c = (line[x - 1] if x else 0), prev[x], (prev[x - 1] if x else 0)
            if kind == 1:
                line[x] = (line[x] + a) & 255
            elif kind == 2:
                line[x] = (line[x] + b) & 255
            elif kind == 3:
                line[x] = (line[x] + (a + b) // 2) & 255
            elif kind == 4:
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                line[x] = (line[x] + (a if pa <= pb and pa <= pc else b if pb <= pc else c)) & 255
        rows.append([value >= 128 for value in line])
        prev = line
    return rows


def today_order_id():
    return datetime.datetime.now().strftime("ORDER-%Y%m%d-%H%M%S")


# ---------------------------------------------------------------- UI

class Back(Exception):
    pass


class App:
    def __init__(self, screen):
        self.s = screen
        self.settings = {"network": "devnet", "wallet": "", "devnet_rpc": DEFAULT_DEVNET_RPC,
                         "mainnet_rpc_primary": "", "mainnet_rpc_fallback": "", **read_json(SETTINGS_FILE, {})}
        self.orders = read_json(ORDERS_FILE, [])
        self.binary = engine_path()
        self.license = license_status(self.binary)
        self.cursor(0)
        self.s.keypad(True)
        self.color = curses.has_colors() and os.environ.get("NO_COLOR") is None
        self.pairs, self.next_pair = {}, 20
        if not self.color:
            return
        curses.start_color()
        curses.use_default_colors()
        rich = curses.COLORS >= 256
        curses.init_pair(1, 87 if rich else curses.COLOR_CYAN, -1)      # brand cyan
        curses.init_pair(2, 141 if rich else curses.COLOR_MAGENTA, -1)  # brand violet
        curses.init_pair(3, 245 if rich else curses.COLOR_WHITE, -1)    # muted
        curses.init_pair(4, curses.COLOR_GREEN, -1)
        curses.init_pair(5, curses.COLOR_YELLOW, -1)
        curses.init_pair(6, curses.COLOR_RED, -1)
        curses.init_pair(7, curses.COLOR_BLACK, 87 if rich else curses.COLOR_CYAN)  # focused
        curses.init_pair(8, curses.COLOR_WHITE, curses.COLOR_BLACK)                 # QR

    # -- drawing primitives
    MONO = {1: curses.A_BOLD, 2: curses.A_BOLD, 3: curses.A_DIM, 4: curses.A_BOLD, 5: curses.A_BOLD,
            6: curses.A_BOLD | curses.A_UNDERLINE, 7: curses.A_REVERSE, 8: curses.A_NORMAL}

    @staticmethod
    def cursor(visible):
        """Show or hide the cursor; simple terminals (e.g. vt100) cannot, which is fine."""
        try:
            curses.curs_set(visible)
        except curses.error:
            pass

    def C(self, number):
        """Colour attribute, or a monochrome equivalent when the terminal has no colours."""
        return curses.color_pair(number) if self.color else self.MONO.get(number, curses.A_NORMAL)

    def logo_pair(self, fg, bg):
        key = (fg, bg)
        if key not in self.pairs:
            curses.init_pair(self.next_pair, fg, bg)
            self.pairs[key] = curses.color_pair(self.next_pair)
            self.next_pair += 1
        return self.pairs[key]

    def draw_logo(self, y, x):
        """Pixel logo in half blocks: colour when available, monochrome strokes otherwise."""
        palette = LOGO_256 if self.color and curses.COLORS >= 256 else LOGO_8
        for row in range(0, len(LOGO), 2):
            top, bottom = LOGO[row], LOGO[row + 1]
            for col in range(LOGO_WIDTH):
                t, b = top[col], bottom[col]
                if not self.color:
                    on_t, on_b = t in "cmvd", b in "cmvd"
                    char = "█" if on_t and on_b else "▀" if on_t else "▄" if on_b else " "
                    self.put(y + row // 2, x + col, char, curses.A_BOLD)
                    continue
                fg = palette.get(t, -1)
                bg = palette.get(b, -1)
                if t == ".":
                    char, attr = ("▄", self.logo_pair(bg, -1)) if b != "." else (" ", 0)
                else:
                    char, attr = "▀", self.logo_pair(fg, bg)
                self.put(y + row // 2, x + col, char, attr)

    def put(self, y, x, text, attr=0):
        h, w = self.s.getmaxyx()
        if 0 <= y < h and x < w:
            try:
                self.s.addstr(y, max(0, x), text[: max(0, w - x - 1)], attr)
            except curses.error:
                pass

    def wrap(self, text, width):
        lines = []
        for paragraph in text.split("\n"):
            line = ""
            for word in paragraph.split(" "):
                while len(word) > width:
                    if line:
                        lines.append(line)
                        line = ""
                    lines.append(word[:width])
                    word = word[width:]
                if len(line) + len(word) + (1 if line else 0) > width:
                    lines.append(line)
                    line = word
                else:
                    line = f"{line} {word}" if line else word
            lines.append(line)
        return lines

    def header(self, network=None):
        """Logo top-left, product name, version, license and network to its right.
        The same header is shown before and after activation."""
        self.s.erase()
        h, w = self.s.getmaxyx()
        network = network or self.settings.get("network", "devnet")
        show_logo = w >= 44 and h >= 14
        x = 2 + LOGO_WIDTH + 3 if show_logo else 2
        room = max(8, w - x - 2)
        if show_logo:
            self.draw_logo(1, 2)
        title = "ZeroClaw Solana Pay" if room >= 19 else "ZeroClaw"
        self.put(1, x, title, self.C(1) | curses.A_BOLD)
        if self.license:
            lic = f"License: Active ({self.license.get('buyerId')})"
            lic = lic if len(lic) + 10 <= room else "License: Active"
        else:
            lic = "License: Not activated"
        version = f"v{APP_VERSION}"
        self.put(2, x, version, self.C(3))
        self.put(2, x + len(version) + 2, lic[: max(0, room - len(version) - 2)], self.C(4 if self.license else 5))
        name = NETWORK_NAMES.get(network, network)
        label = f"Network: {name}" + (" (real money)" if network == "mainnet-beta" else "")
        self.put(3, x, label[:room], self.C(6 if network == "mainnet-beta" else 4) | curses.A_BOLD)
        if show_logo:
            self.put(4, x, "SOL and USDC payment links"[:room], self.C(3))
        self.put(5, 2, "─" * max(10, w - 4), self.C(3))
        return 7

    def footer(self, hint):
        h, w = self.s.getmaxyx()
        lines = self.wrap(hint, w - 4) if hint else []
        for i, line in enumerate(lines[:2]):
            self.put(h - 3 + i, 2, line, self.C(3))
        keys = "↑/↓ move · Enter select · Esc back" if w >= 40 else "↑↓ Enter Esc"
        self.put(h - 1, 2, keys, self.C(3) | curses.A_DIM)

    def key(self):
        ch = self.s.get_wch()
        if ch == curses.KEY_RESIZE:
            return "resize"
        return ch

    # -- widgets
    def menu(self, title, items, hint="", network=None, intro=None, start=0):
        """items: list of labels. Returns index; raises Back on Esc."""
        index = start
        while True:
            y = self.header(network)
            self.put(y, 2, title, curses.A_BOLD)
            y += 2
            if intro:
                for line in self.wrap(intro, self.s.getmaxyx()[1] - 6):
                    self.put(y, 2, line)
                    y += 1
                y += 1
            for i, label in enumerate(items):
                text = f" {i + 1}. {label} " if len(items) < 10 else f" {label} "
                self.put(y + i, 4, text, self.C(7) | curses.A_BOLD if i == index else 0)
            self.footer(hint)
            ch = self.key()
            if ch in (curses.KEY_UP, "k"):
                index = (index - 1) % len(items)
            elif ch in (curses.KEY_DOWN, "\t", "j"):
                index = (index + 1) % len(items)
            elif ch in ("\n", "\r", curses.KEY_ENTER):
                return index
            elif ch in ("\x1b", curses.KEY_BACKSPACE, "\x7f"):
                raise Back()
            elif isinstance(ch, str) and ch.isdigit() and 1 <= int(ch) <= len(items) and len(items) < 10:
                return int(ch) - 1

    def form(self, title, fields, buttons, hint="", network=None, intro=None, error=None, focus=0):
        """fields: list of dicts(label, value, mask). Returns (button_index, values); raises Back on Esc."""
        values = [f.get("value", "") for f in fields]
        total = len(fields) + len(buttons)
        while True:
            y = self.header(network)
            self.put(y, 2, title, curses.A_BOLD)
            y += 2
            width = self.s.getmaxyx()[1]
            if intro:
                for line in self.wrap(intro, width - 6):
                    self.put(y, 2, line)
                    y += 1
                y += 1
            cursor = None
            for i, field in enumerate(fields):
                self.put(y, 2, field["label"], self.C(3))
                shown = ("•" * len(values[i])) if field.get("mask") else values[i]
                box_width = min(width - 6, max(40, len(shown) + 2))
                visible = shown[-(box_width - 2):]
                attr = self.C(1) | curses.A_BOLD if focus == i else 0
                self.put(y + 1, 2, "› " + visible.ljust(box_width - 2), attr | curses.A_UNDERLINE)
                if focus == i:
                    cursor = (y + 1, 4 + len(visible))
                y += 3
            for j, label in enumerate(buttons):
                selected = focus == len(fields) + j
                self.put(y + j, 4, f" {label} ", self.C(7) | curses.A_BOLD if selected else self.C(1))
            if error:
                for k, line in enumerate(self.wrap(error, width - 6)[:3]):
                    self.put(y + len(buttons) + 1 + k, 2, line, self.C(6) | curses.A_BOLD)
            self.footer(hint)
            if cursor:
                self.cursor(1)
                try:
                    self.s.move(*cursor)
                except curses.error:
                    pass
            else:
                self.cursor(0)
            ch = self.key()
            self.cursor(0)
            if ch in (curses.KEY_UP,):
                focus = (focus - 1) % total
            elif ch in (curses.KEY_DOWN, "\t"):
                focus = (focus + 1) % total
            elif ch == "\x1b":
                raise Back()
            elif ch in ("\n", "\r", curses.KEY_ENTER):
                if focus < len(fields):
                    return 0, [v.strip() for v in values]
                return focus - len(fields), [v.strip() for v in values]
            elif focus < len(fields):
                if ch in (curses.KEY_BACKSPACE, "\x7f", "\b"):
                    values[focus] = values[focus][:-1]
                elif ch == "\x15":  # Ctrl+U clears the field
                    values[focus] = ""
                elif isinstance(ch, str) and ch.isprintable():
                    values[focus] = (values[focus] + ch)[:256]
                error = None
            elif isinstance(ch, str) and ch.isdigit() and 1 <= int(ch) <= len(buttons):
                return int(ch) - 1, [v.strip() for v in values]

    def notice(self, title, lines, buttons=("Back",), hint="", network=None):
        """lines: list of (text, attr) or str. Returns the chosen button; Esc picks the last one."""
        try:
            return self._notice(title, lines, buttons, hint, network)
        except Back:
            return len(buttons) - 1

    def _notice(self, title, lines, buttons, hint, network):
        focus, offset = 0, 0
        while True:
            y = self.header(network)
            h, w = self.s.getmaxyx()
            self.put(y, 2, title, curses.A_BOLD)
            y += 2
            rendered = []
            for item in lines:
                text, attr = (item, 0) if isinstance(item, str) else item
                for line in self.wrap(text, w - 6):
                    rendered.append((line, attr))
            room = max(3, h - y - len(buttons) - 5)
            offset = min(offset, max(0, len(rendered) - room))
            for i, (line, attr) in enumerate(rendered[offset:offset + room]):
                self.put(y + i, 2, line, attr)
            if len(rendered) > room:
                self.put(y + room, 2, f"PgUp/PgDn to scroll ({offset + 1}-{min(len(rendered), offset + room)} of {len(rendered)})",
                         self.C(3))
            by = y + min(room, len(rendered)) + 2
            for j, label in enumerate(buttons):
                self.put(by + j, 4, f" {j + 1}. {label} ", self.C(7) | curses.A_BOLD if j == focus else self.C(1))
            self.footer(hint)
            ch = self.key()
            if ch == curses.KEY_UP:
                focus = (focus - 1) % len(buttons)
            elif ch in (curses.KEY_DOWN, "\t"):
                focus = (focus + 1) % len(buttons)
            elif ch == curses.KEY_NPAGE:
                offset += room
            elif ch == curses.KEY_PPAGE:
                offset = max(0, offset - room)
            elif ch in ("\n", "\r", curses.KEY_ENTER):
                return focus
            elif isinstance(ch, str) and ch.isdigit() and 1 <= int(ch) <= len(buttons):
                return int(ch) - 1
            elif ch in ("\x1b", curses.KEY_BACKSPACE, "\x7f"):
                raise Back()

    def busy(self, title, text, network=None):
        y = self.header(network)
        self.put(y, 2, title, curses.A_BOLD)
        self.put(y + 2, 2, text, self.C(1))
        self.s.refresh()

    # -- persistence
    def save_settings(self):
        write_private(SETTINGS_FILE, json.dumps(self.settings, indent=2) + "\n")

    def save_orders(self):
        write_private(ORDERS_FILE, json.dumps(self.orders, indent=2) + "\n")

    # -- screens
    def run(self):
        while True:
            try:
                if not self.license:
                    self.activation()
                else:
                    if self.main_menu() == "exit":
                        return
            except Back:
                if not self.license:
                    return

    def activation(self):
        error = None
        while True:
            choice, values = self.form(
                "Activate ZeroClaw",
                [{"label": "Paste your access token (Ctrl+Shift+V), then press Enter", "value": "", "mask": True}],
                ["Activate", "Contact Sales (buy a license)", "Exit"],
                intro="Paste the access token from your purchase message. ZeroClaw downloads your licensed "
                      "engine and checks your license before saving it.",
                hint="No token yet? Choose Contact Sales to buy a US$200 one-time license. You receive your token after payment.",
                error=error)
            if choice == 1:
                error = "Opening Sales on WhatsApp in your browser." if open_external(SALES_URL) else f"Contact Sales: {SALES_URL}"
                continue
            if choice == 2:
                raise Back()
            token = values[0]
            try:
                self.busy("Activate ZeroClaw", "Contacting the ZeroClaw registry...")
                checked = activate(token, progress=lambda text: self.busy("Activate ZeroClaw", text))
            except ActivationError as failure:
                error = ACTIVATION_MESSAGES.get(str(failure), ACTIVATION_MESSAGES["server"])
                continue
            finally:
                token = None
            self.binary = engine_path()
            self.license = license_status(self.binary) or checked
            self.notice("ZeroClaw is active", [
                (f"License {self.license.get('licenseId')} for {self.license.get('buyerId')} is active.", self.C(4) | curses.A_BOLD),
                "Next time you open ZeroClaw it goes straight to the main menu.",
                "Start with How to Use, or create your first Devnet invoice.",
            ], buttons=("Continue",), hint="Your license works offline from now on.")
            return

    def main_menu(self):
        index = 0
        while True:
            try:
                index = self.menu("Main menu", ["Create Payment", "Check Payment Status", "Settings", "How to Use", "Exit"],
                                  hint="New here? Open How to Use and create your first Devnet invoice.",
                                  network=self.settings["network"], start=index)
            except Back:
                continue
            try:
                if index == 0:
                    self.create_payment()
                elif index == 1:
                    self.check_status()
                elif index == 2:
                    self.settings_menu()
                elif index == 3:
                    self.guide()
                else:
                    return "exit"
            except Back:
                continue

    def ensure_wallet(self, network):
        if valid_wallet(self.settings.get("wallet", "")):
            return True
        self.edit_wallet(network, reason="Set the public wallet address that receives payments first.")
        return valid_wallet(self.settings.get("wallet", ""))

    def create_payment(self, network=None, token=None, amount="", first=False):
        network = network or self.settings["network"]
        if network == "mainnet-beta" and not self.settings.get("mainnet_rpc_primary"):
            self.notice("Mainnet is not configured", ["Add your Mainnet RPC endpoint in Settings > Network first."],
                        network=network)
            return
        if not self.ensure_wallet(network):
            return
        if token is None:
            pick = self.menu("Create a payment - choose a token", ["USDC (USD Coin)", "SOL"],
                             hint="Your customer pays in this token from their own Solana wallet.", network=network)
            token = ["USDC", "SOL"][pick]
            amount = amount or ("1" if token == "USDC" else "0.01")
        order_id, error = today_order_id(), None
        while True:
            choice, values = self.form(
                f"Create a payment - {token}",
                [{"label": f"Amount in {token}", "value": amount}, {"label": "Order ID (letters, numbers, - or _)", "value": order_id}],
                ["Review", "Cancel"], network=network, error=error,
                intro="Create your first Devnet invoice: 1 USDC is filled in as an example." if first else None,
                hint="Use your own order ID so you can find this payment later.")
            if choice == 1:
                return
            amount, order_id = values
            if not AMOUNT_RE.match(amount) or float(amount) <= 0:
                error = "Enter an amount such as 1 or 0.5."
            elif not ORDER_RE.match(order_id):
                error = "Order ID can use letters, numbers, - and _ only (max 64)."
            elif any(o["order_id"] == order_id and o["network"] == network for o in self.orders):
                error = "This order ID is already used on this network. Choose another one."
            else:
                break
        wallet = self.settings["wallet"]
        lines = [(f"Network:  {NETWORK_NAMES[network]}", self.C(6 if network == "mainnet-beta" else 4) | curses.A_BOLD),
                 f"Receive to:  {wallet}", f"Amount:  {amount} {token}", f"Order ID:  {order_id}"]
        if network == "mainnet-beta":
            lines.append(("Mainnet uses real money. Check the address carefully.", self.C(6) | curses.A_BOLD))
        if self.notice("Review your payment", lines, buttons=("Create payment", "Cancel"), network=network,
                       hint="Check the network and the receiving address. Payments go straight to this wallet.") != 0:
            return
        self.busy("Creating payment", "Creating your payment link...", network)
        env = network_env(self.settings, network, wallet)
        code, data, message = run_engine(self.binary, ["create-url", "--amount", amount, "--token", token, "--order-id", order_id], env)
        if code != 0 or not data:
            self.notice("Could not create the payment", [(message or "Unknown error.", self.C(6)),
                                                         "Check Settings (wallet and network) and try again."], network=network)
            return
        folder = private_dir(pictures_dir())
        qr = os.path.join(folder, f"{order_id}-{network}.png")
        run_engine(self.binary, ["render-qr", "--url", data["url"], "--out", qr], env)
        record = {"order_id": order_id, "reference": data["reference"], "network": network, "token": token,
                  "amount": data.get("amount_ui", amount), "url": data["url"], "qr": qr, "recipient": wallet,
                  "created_at": datetime.datetime.now().isoformat(timespec="seconds"), "status": "pending"}
        self.orders.append(record)
        self.save_orders()
        self.show_invoice(record)

    def qr_lines(self, record):
        small = os.path.join(tempfile.gettempdir(), f"zeroclaw-qr-{os.getpid()}.png")
        env = network_env(self.settings, record["network"], record["recipient"])
        code, _, _ = run_engine(self.binary, ["render-qr", "--url", record["url"], "--out", small, "--scale", "1", "--quiet-zone", "2"], env)
        try:
            rows = png_modules(small) if code == 0 else None
        finally:
            if os.path.exists(small):
                os.unlink(small)
        if not rows:
            return None
        lines = []
        for y in range(0, len(rows), 2):
            top, bottom = rows[y], rows[y + 1] if y + 1 < len(rows) else [True] * len(rows[y])
            lines.append("".join("█" if t and b else "▀" if t else "▄" if b else " " for t, b in zip(top, bottom)))
        return lines

    def show_qr(self, record, qr):
        """Only the QR, centred, so it can be scanned from the screen."""
        while True:
            self.s.erase()
            h, w = self.s.getmaxyx()
            caption = f"Order {record['order_id']} · {record['amount']} {record['token']} · {NETWORK_NAMES[record['network']]}"
            if len(qr) + 4 > h or len(qr[0]) + 2 > w:
                self.put(1, 2, f"Make the window bigger to show the QR here (needs {len(qr) + 4} rows and {len(qr[0]) + 2} columns,", self.C(5) | curses.A_BOLD)
                self.put(2, 2, f"this window has {h} x {w}). Or go back and choose Open QR image.", self.C(5) | curses.A_BOLD)
            else:
                top, left = max(0, (h - len(qr) - 3) // 2), max(0, (w - len(qr[0])) // 2)
                for i, row in enumerate(qr):
                    self.put(top + i, left, row, self.C(8))
                self.put(top + len(qr) + 1, max(0, (w - len(caption)) // 2), caption, self.C(1) | curses.A_BOLD)
            self.put(h - 1, 2, "Scan with a Solana wallet · Esc to go back", self.C(3))
            ch = self.key()
            if ch != "resize":
                return

    def show_invoice(self, record):
        message = None
        qr = self.qr_lines(record)
        while True:
            h, w = self.s.getmaxyx()
            lines = [(f"Payment created on {NETWORK_NAMES[record['network']]}", self.C(4) | curses.A_BOLD),
                     f"Order ID:  {record['order_id']}", f"Amount:  {record['amount']} {record['token']}",
                     "Payment link:", (record["url"], self.C(1))]
            if message:
                lines.append((message, self.C(5) | curses.A_BOLD))
            buttons = ("Copy link", "Save QR image", "Show QR full screen", "Open QR image", "Check payment status", "Main menu")
            header_rows = 9 if h >= 22 and w >= 72 else 5
            text_rows = sum(len(self.wrap(item if isinstance(item, str) else item[0], w - 6)) for item in lines) + 1
            fits = bool(qr) and header_rows + 2 + text_rows + len(qr) + 2 + len(buttons) + 3 <= h and len(qr[0]) + 4 <= w
            if fits:
                lines.append("QR code (scan with a Solana wallet):")
                lines += [(row, self.C(8)) for row in qr]
            else:
                lines.append(("Choose Show QR full screen to scan it from this window, or Open QR image.", self.C(3)))
            try:
                choice = self._notice("Your payment is ready", lines, buttons,
                                      "Share this link or QR with your customer. Return to Check payment status after they pay.",
                                      record["network"])
            except Back:
                return
            if choice == 0:
                if copy_text(record["url"]):
                    message = "Link copied to the clipboard."
                else:
                    path = os.path.join(private_dir(DATA_DIR), "links", f"{record['order_id']}.txt")
                    write_private(path, record["url"] + "\n")
                    message = f"No clipboard tool found. Link saved to {path} - select the link above and press Ctrl+Shift+C."
            elif choice == 1:
                message = f"QR image saved: {record['qr']}" if os.path.exists(record["qr"]) else "QR image is missing; create the payment again."
            elif choice == 2:
                if qr:
                    self.show_qr(record, qr)
                else:
                    message = "The QR could not be drawn here. Choose Open QR image."
            elif choice == 3:
                message = "Opening the QR image..." if open_external(record["qr"]) else f"QR image: {record['qr']}"
            elif choice == 4:
                self.status_for(record)
                message = None
            else:
                return

    def check_status(self):
        while True:
            recent = list(reversed(self.orders))[:9]
            items = [f"{o['order_id']}  ·  {o['amount']} {o['token']}  ·  {NETWORK_NAMES[o['network']]}  ·  {o['status'].capitalize()}"
                     for o in recent] + ["Enter an order ID", "Back"]
            pick = self.menu("Check payment status", items, network=self.settings["network"],
                             hint="Pick a payment you created, or type its order ID.")
            if pick == len(items) - 1:
                return
            if pick == len(items) - 2:
                try:
                    _, values = self.form("Check payment status", [{"label": "Order ID", "value": ""}], ["Check", "Cancel"],
                                          network=self.settings["network"])
                except Back:
                    continue
                matches = [o for o in reversed(self.orders) if o["order_id"] == values[0]]
                if not matches:
                    self.notice("Order not found", [f"No payment with order ID {values[0] or '(empty)'} was created in this app."],
                                network=self.settings["network"])
                    continue
                self.status_for(matches[0])
            else:
                self.status_for(recent[pick])

    def status_for(self, record):
        network = record["network"]
        while True:
            if network == "mainnet-beta" and not self.settings.get("mainnet_rpc_primary"):
                self.notice("Mainnet is not configured", ["Add your Mainnet RPC endpoint in Settings > Network to check this payment."],
                            network=network)
                return
            self.busy("Checking payment", f"Checking order {record['order_id']} on {NETWORK_NAMES[network]}...", network)
            code, data, message = run_engine(self.binary, ["settle", "--reference", record["reference"]],
                                             network_env(self.settings, network, record["recipient"]))
            lines = [f"Order ID:  {record['order_id']}", f"Amount:  {record['amount']} {record['token']}"]
            if code == 0 and data and data.get("status") == "paid":
                record["status"] = "paid"
                lines.insert(0, ("Paid - payment verified on chain", self.C(4) | curses.A_BOLD))
                if data.get("signature"):
                    cluster = "" if network == "mainnet-beta" else "?cluster=devnet"
                    lines.append(f"Transaction: https://explorer.solana.com/tx/{data['signature']}{cluster}")
                hint = "This payment is verified. Deliver the order once."
            elif code == 0 and data and data.get("status") == "pending":
                record["status"] = "pending"
                lines.insert(0, ("Pending - no matching payment yet", self.C(5) | curses.A_BOLD))
                hint = "Ask the customer to pay with the link or QR, then choose Check again."
            elif code == 0 and data:
                record["status"] = data.get("status", "unknown")
                lines.insert(0, (f"{record['status'].capitalize()} - {data.get('reason') or 'the payment does not match this order'}",
                                 self.C(6) | curses.A_BOLD))
                hint = "Do not deliver the order. Compare the amount and token with the customer."
            else:
                lines.insert(0, ("Could not check the payment", self.C(6) | curses.A_BOLD))
                lines.append(message or "Unknown error.")
                hint = ("The Solana network could not be reached. Check your internet connection and choose Check again."
                        if code == 4 else "Fix the problem in Settings, then choose Check again.")
            self.save_orders()
            try:
                if self._notice("Payment status", lines, ("Check again", "Back"), hint, network) != 0:
                    return
            except Back:
                return

    def edit_wallet(self, network=None, reason=None):
        error = reason
        while True:
            try:
                _, values = self.form("Receiving wallet", [{"label": "Your public Solana wallet address", "value": self.settings.get("wallet", "")}],
                                      ["Save", "Cancel"], network=network or self.settings["network"], error=error,
                                      hint="Use a public address only. Never paste a seed phrase or private key.")
            except Back:
                return
            if valid_wallet(values[0]):
                self.settings["wallet"] = values[0]
                self.save_settings()
                return
            error = "That is not a valid Solana address (base58, 32 bytes). Copy it again from your wallet."

    def settings_menu(self):
        while True:
            s = self.settings
            items = [f"Receiving wallet: {s.get('wallet') or 'Not set'}",
                     f"Network: {NETWORK_NAMES[s['network']]}",
                     f"Devnet RPC: {s.get('devnet_rpc') or DEFAULT_DEVNET_RPC}",
                     f"Mainnet RPC: {'Set' if s.get('mainnet_rpc_primary') else 'Not set'}", "Back"]
            pick = self.menu("Settings", items, network=s["network"],
                             hint="Devnet is the default and uses test tokens. Mainnet uses real money.")
            if pick == 0:
                self.edit_wallet()
            elif pick == 1:
                self.choose_network()
            elif pick == 2:
                try:
                    _, values = self.form("Devnet RPC", [{"label": "Devnet RPC URL (https)", "value": s.get("devnet_rpc") or DEFAULT_DEVNET_RPC}],
                                          ["Save", "Cancel"], network="devnet")
                    if values[0].startswith("https://"):
                        s["devnet_rpc"] = values[0]
                        self.save_settings()
                except Back:
                    pass
            elif pick == 3:
                self.mainnet_rpc()
            else:
                return

    def mainnet_rpc(self):
        error = None
        while True:
            try:
                choice, values = self.form(
                    "Mainnet RPC", [{"label": "Mainnet RPC URL (https, from your provider)", "value": self.settings.get("mainnet_rpc_primary", "")},
                                    {"label": "Second Mainnet RPC URL (optional)", "value": self.settings.get("mainnet_rpc_fallback", "")}],
                    ["Save", "Cancel"], network="mainnet-beta", error=error,
                    hint="ZeroClaw checks that each endpoint really is Mainnet and never falls back to Devnet.")
            except Back:
                return
            if choice == 1:
                return
            if not values[0].startswith("https://") or (values[1] and not values[1].startswith("https://")):
                error = "RPC URLs must start with https://"
                continue
            self.settings["mainnet_rpc_primary"], self.settings["mainnet_rpc_fallback"] = values
            self.save_settings()
            return

    def choose_network(self):
        pick = self.menu("Choose a network", ["Devnet (test tokens, default)", "Mainnet (real SOL and USDC)", "Back"],
                         network=self.settings["network"],
                         hint="Payments are checked on the network the invoice was created on.")
        if pick == 0:
            self.settings["network"] = "devnet"
            self.save_settings()
        elif pick == 1:
            try:
                _, values = self.form(
                    "Switch to Mainnet", [{"label": "Type MAINNET to confirm", "value": ""}], ["Confirm", "Cancel"],
                    network="mainnet-beta",
                    intro="Mainnet is the real Solana network. Customers pay with real SOL or USDC. ZeroClaw then "
                          "requires: your own Mainnet RPC endpoint, final confirmation of every payment, and an order "
                          "ID for every invoice. Supports Solana Mainnet. The payment workflow was tested on Solana Devnet.",
                    hint="Start with a small real payment before you take live orders.")
            except Back:
                return
            if values[0] != "MAINNET":
                return
            if not self.settings.get("mainnet_rpc_primary"):
                self.mainnet_rpc()
            if self.settings.get("mainnet_rpc_primary"):
                self.settings["network"] = "mainnet-beta"
                self.save_settings()

    def guide(self):
        text = [
            ("How to use ZeroClaw", curses.A_BOLD),
            "ZeroClaw creates Solana payment links and QR codes for your orders and checks whether each payment arrived. "
            "Customers pay from their own wallet straight to your wallet. ZeroClaw never holds your money or keys.",
            "",
            ("1. Set your receiving wallet", self.C(1) | curses.A_BOLD),
            "Settings > Receiving wallet. Paste your public Solana address (never a seed phrase).",
            ("2. Create a payment", self.C(1) | curses.A_BOLD),
            "Choose USDC or SOL, enter the amount and your order ID, check the network and address, then create it.",
            ("3. Share the link or QR", self.C(1) | curses.A_BOLD),
            "Copy the link or save the QR image and send it to your customer.",
            ("4. Check the payment", self.C(1) | curses.A_BOLD),
            "Check payment status shows Pending until the payment is verified on chain, then Paid. Deliver the order only when it says Paid.",
            "",
            ("Devnet and Mainnet", self.C(2) | curses.A_BOLD),
            "Devnet is the default and uses free test tokens, so you can practise safely. A Devnet wallet "
            "(for example Phantom with Testnet mode on) can pay Devnet invoices.",
            "Mainnet uses real money. Switch in Settings > Network after adding your Mainnet RPC endpoint. "
            "Supports Solana Mainnet. The payment workflow was tested on Solana Devnet.",
            "",
            ("For developers", self.C(2) | curses.A_BOLD),
            "Run the same engine from a terminal: zeroclaw cli --help",
        ]
        try:
            pick = self._notice("How to use ZeroClaw", text, ("Create your first Devnet invoice", "Back"),
                                "Your first invoice uses Devnet and 1 USDC as an example. You only enter your own wallet address.", None)
        except Back:
            return
        if pick == 0:
            self.create_payment(network="devnet", token="USDC", amount="1", first=True)


USAGE = """ZeroClaw Solana Pay {version}

  zeroclaw              open the interactive app (logo, activation, menus)
  zeroclaw status       print the license status as JSON (for scripts)
  zeroclaw cli ARGS...  run the ZeroClaw engine directly (developers)
  zeroclaw --version    print the version
"""


def main():
    args = sys.argv[1:]
    if args[:1] in (["--version"], ["-V"]):
        print(f"zeroclaw {APP_VERSION}")
        return 0
    if args[:1] in (["--help"], ["-h"], ["help"]):
        print(USAGE.format(version=APP_VERSION), end="")
        return 0
    if args[:1] == ["status"]:
        # Script-friendly: JSON only, never the interactive header.
        binary = engine_path()
        if not binary or not os.path.exists(license_path()):
            print(json.dumps({"activated": False}))
            return 3
        os.execv(binary, [binary, "license-check"])
    if args[:1] == ["cli"]:
        binary = engine_path()
        if not binary:
            print("ZeroClaw is not activated yet. Open ZeroClaw from the app menu and paste your access token.", file=sys.stderr)
            return 3
        os.execv(binary, [binary, *args[1:]])
    if args:
        print(f"zeroclaw: unknown command {args[0]!r}\n\n" + USAGE.format(version=APP_VERSION), end="", file=sys.stderr)
        return 2
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        print("ZeroClaw needs a terminal window. Open it from the app menu.", file=sys.stderr)
        return 2
    os.environ.setdefault("ESCDELAY", "25")
    try:
        curses.wrapper(lambda screen: App(screen).run())
    except curses.error:
        print("ZeroClaw could not start in this terminal. Open it from the app menu or a standard terminal.", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
